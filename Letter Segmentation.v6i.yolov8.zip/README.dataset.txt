# Letter Segmentation > 2024-07-02 2:49am
https://universe.roboflow.com/letter-segmentation/letter-segmentation-zhtwv

Provided by a Roboflow user
License: CC BY 4.0

